#ifndef GRAVEYARDSGUI_H
#define GRAVEYARDSGUI_H

#include <QListWidget>
#include "QLabel"
#include "QCheckBox"
#include "QPoint"

class GraveyardsGui : public QListWidget
{
    Q_OBJECT

  public:
    explicit GraveyardsGui(int pawnSize, QWidget * parent = nullptr);
    void addPawn(const QPixmap & pixmap);

  protected:


    int _pawnSize;
};
#endif // GRAVEYARDSGUI_H
