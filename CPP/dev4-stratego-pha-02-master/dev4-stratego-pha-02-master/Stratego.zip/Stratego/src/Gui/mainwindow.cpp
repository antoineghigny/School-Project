#include "mainwindow.h"
#include "Model.h"

#include "BoardGui.h"
#include "leftWidget.h"

#include <QtWidgets>
#include <stdlib.h>
#include "QtDebug"

#include "QPushButton"

#include "QCheckBox"
#include "QVBoxLayout"
#include "QLabel"
#include "GraveyardsGui.h"
#include "DropFile.h"
#include "controllergui.h"


#include <thread>

MainWindow::MainWindow(QWidget * parent, ControllerGui * controller)
    : QMainWindow(parent),
      _controller{controller}, _leftWidget{new LeftWidget(this, controller)}, _isImportFile{false}
{
    setupMenus();
    setupWidgets();
    inputGameMode();
    setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed));
    setWindowTitle(tr("Stratego"));
}


void MainWindow::updateView(Model * m)
{
    std::cout << "updateview main" << std::endl;
    // TODO CHANGER ABSOLUMENT VERS UN EVENT QUI REFRESH
    resize(600, 600);

    if(_controller->isSetUpFinish()){
        std::cout << "setupgraveyards" << std::endl;
        setGraveyards();
        _controller->setToSetUpFinish();
    }
    switch (m->getState())
    {
    case NOT_STARTED:
        std::cout << "not started" << std::endl;
        inputGameMode();
        break;
    case SET_UP:
        if(_isImportFile){
            _isImportFile = false;
            setupBoardForFile();
        }
        askPlacement();
        break;
    case MOVE_PAWN:
        std::cout << "movepawn dans mainwindow" << std::endl;
        if(m->getDuelResult() != 2){
            fillGraveyards(m->getDuelResult());
        }
        break;
    case END_TURN:
        break;
    case GAME_OVER:
        break;
    }

}

QLabel * MainWindow::displayCurrentPlayer()
{
    int currentPlayer = _controller->getCurrentPlayer();
    QString player;
    if (currentPlayer == 0)
    {
        player = "BLUE";
    }
    else
    {
        player = "RED";
    }
    std::string test;
    QLabel * label = new QLabel();
    label->setText("Player" + player);
    return label;
}

void MainWindow::inputGameMode()
{

    QLabel * question = new QLabel("Do you want to play the game in easy mode ?");
    _checkbox = new QCheckBox("YES");
    QPushButton * start = new QPushButton("START");

    connect(start, SIGNAL(clicked()), this, SLOT(startGame()));
    _leftWidget->askGameMode(question, _checkbox, start);
}

void MainWindow::startGame()
{
    _controller->checkInputGameMode(_checkbox->isChecked());
}


void MainWindow::askPlacement()
{
    QLabel * label = new
    QLabel("Do you want to import a text file including your Board or manually place your pawns?");
    QPushButton * importFile = new QPushButton("Import a file");
    QPushButton * manualPlacement = new QPushButton("Manual placement");
    connect(manualPlacement, SIGNAL(clicked()), this, SLOT(setupDeck()));
    connect(importFile, SIGNAL(clicked()), this, SLOT(setUpFile()));
    _leftWidget->addQuestions(label, importFile, manualPlacement);
}

bool MainWindow::valueOfChoice(bool value)
{
    return value;
}

void MainWindow::setGraveyards()
{
    _blueGraveyards = new GraveyardsGui{_sizeBoard / 10, this};
    _deck = nullptr;

    _redGraveyards = new GraveyardsGui{_sizeBoard / 10, this};
    _leftWidget->addGraveyards(_blueGraveyards, _redGraveyards);
}

void MainWindow::fillGraveyards(int duelResult) // l'appeler quand y'a un pion qui est mort
{
    std::vector<std::pair<Role, Team>> listDeadPawns = {};

    if(duelResult == -1){
         listDeadPawns.push_back(_controller->getLastDeadPawn(
                            _controller->getCurrentPlayer()));
    }else if(duelResult == 1){
        listDeadPawns.push_back(_controller->getLastDeadPawn(
                            (_controller->getCurrentPlayer()+1) % 2));
    }else{


        listDeadPawns.push_back(_controller->getLastDeadPawn(
                                    _controller->getCurrentPlayer())); // 1 et // 0
        listDeadPawns.push_back(_controller->getLastDeadPawn( // 0 et //1
                            (_controller->getCurrentPlayer()+1) % 2));
    }

    for(auto deadPawn : listDeadPawns){
        _pixmap.load(imagePixmap(deadPawn.first, deadPawn.second));

        _pixmap = _pixmap.copy((_pixmap.width()),(_pixmap.height()), _pixmap.width(),_pixmap.height()).scaled(_boardGui->width() / _controller->getBoardSize(),
                                                       _boardGui->height() / _controller->getBoardSize(),
                                                       Qt::IgnoreAspectRatio,
                                                       Qt::SmoothTransformation);

        if (deadPawn.second == 0)
        {
            _blueGraveyards->addPawn(_pixmap);
        }
        else
        {
            _redGraveyards->addPawn(_pixmap);
        }
    }
}

void MainWindow::setupMenus()
{
    QMenu * fileMenu = menuBar()->addMenu(tr("&File"));

    //    QAction * openAction = fileMenu->addAction(tr("&Open..."), this,
    //                           &MainWindow::openImage);
    //openAction->setShortcuts(QKeySequence::Open);

    QAction * exitAction = fileMenu->addAction(tr("E&xit"), qApp,
                           &QCoreApplication::quit);
    exitAction->setShortcuts(QKeySequence::Quit);

    QMenu * gameMenu = menuBar()->addMenu(tr("&Game"));

    gameMenu->addAction(tr("&Restart"), this,
                        &MainWindow::setupDeck);
}

void MainWindow::setupWidgets()
{
    std::cout << "setup widget" << std::endl;
    QFrame * frame = new QFrame;
    QVBoxLayout * vboxLayout = new QVBoxLayout(frame);
    QHBoxLayout * frameLayout = new QHBoxLayout();

    QGroupBox * horizontalGroupBox = new QGroupBox();

    _sizeBoard = 500;

    _boardGui = new BoardGui{_sizeBoard, this, _controller};

    // auto currentPlayer = displayCurrentPlayer();


    frameLayout->addWidget(_leftWidget);
    frameLayout->addWidget(_boardGui);
    //vboxLayout->addWidget(currentPlayer);
    horizontalGroupBox->setLayout(frameLayout);
    vboxLayout->addWidget(horizontalGroupBox);
    std::cout << "boardgui : " << _boardGui << std::endl;
    _controller->addObserver(_boardGui);

    setCentralWidget(frame);
}

void MainWindow::setupDeck()
{
    _deck = new DeckGui{_sizeBoard / 10, nullptr};
    _controller->generateDeck();
    int numberOfPawn {_controller->getDeckSize()}; // 40 sur 4 lignes
    int currentPlayer = _controller->getCurrentPlayer();

    for (int index = 0; index < _controller->getDeckSize(); ++index)
    {
        _pixmap.load(imagePixmap(_controller->getPawnInDeckAt(
                                         index).getRole(), _controller->getPawnInDeckAt(index).getTeam()));

        _pixmap = _pixmap.copy((_pixmap.width()),(_pixmap.height()), _pixmap.width(),_pixmap.height()).scaled(_boardGui->width() / _controller->getBoardSize(),
                                                       _boardGui->height() / _controller->getBoardSize(),
                                                       Qt::IgnoreAspectRatio,
                                                       Qt::SmoothTransformation);


        _deck->addPawn(_pixmap, currentPlayer);
    }
    _leftWidget->addDeck(_deck);
}

void MainWindow::setUpFile()
{
    _isImportFile = true;
    QLabel * label = new
    QLabel("Please Drag & Drop your file containing the board just bellow");
    DropFile * dropFile = new DropFile(nullptr, _controller);
    _leftWidget->addDropFile(label, dropFile);
}

void MainWindow::setupBoardForFile()
{

    int currentPlayer = _controller->getCurrentPlayer();

    int begin {};


    (_controller->getCurrentPlayer() == 0) ? begin = 6 : begin = 0;

    for (int x = begin; x <= (begin+3); ++x)
    {
        for (int y = 0; y < _controller->getBoardSize(); ++y)
        {

        _pixmap.load(imagePixmap(_controller->getPawn(Position(x+1, y+1)).getRole(),_controller->getPawn(Position(x+1, y+1)).getTeam()));


        _pixmap = _pixmap.copy((_pixmap.width()),(_pixmap.height()), _pixmap.width(),_pixmap.height()).scaled(_boardGui->width() / _controller->getBoardSize(),
                                                       _boardGui->height() / _controller->getBoardSize(),
                                                       Qt::IgnoreAspectRatio,
                                                       Qt::SmoothTransformation);

            _boardGui->placePawnFile(y, x, _pixmap, currentPlayer);
        }
    }
}

QString MainWindow::imagePixmap(Role role, Team team)
{
    QString s;
    s += ":/images/allPawns";
    switch (team)
    {
        case 0:
            s += "/blue/";
            break;
        case 1:
            s += "/red/";
            break;
    }
    QString roleString = QString::number(role);
    s += roleString;
    s += ".png";
    return s;
}
