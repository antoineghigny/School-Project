#ifndef DROPFILE_H
#define DROPFILE_H

#include <QLabel>
#include "controllergui.h"


QT_BEGIN_NAMESPACE
class QMimeData;
QT_END_NAMESPACE

//! [DropArea header part1]
class DropFile : public QLabel
{
    Q_OBJECT

  public:
    explicit DropFile(QWidget * parent = nullptr, ControllerGui * controllerGui = nullptr, MainWindow * mainWindow = nullptr);
    void test();
  public slots:
    void clear();
  protected:
    void dragEnterEvent(QDragEnterEvent * event) override;
    void dragMoveEvent(QDragMoveEvent * event) override;
    void dragLeaveEvent(QDragLeaveEvent * event) override;
    void dropEvent(QDropEvent * event) override;

  private:
    ControllerGui * _controller;

    QLabel * label;

    MainWindow * _mainWindow;
};

#endif // DROPFILE_H
