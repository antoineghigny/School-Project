#include "deckgui.h"
#include "iostream"
#include <QDrag>
#include <QDragEnterEvent>
#include <QMimeData>
#include "QPoint"

DeckGui::DeckGui(int pawnSize, QWidget * parent)
    : _pawnSize(pawnSize), QListWidget(parent)
{
    setDragEnabled(true);
    setViewMode(QListView::IconMode);
    setIconSize(QSize(pawnSize, pawnSize));
    setSpacing(10);
    setAcceptDrops(false);
    setDropIndicatorShown(true);
}

void DeckGui::dragEnterEvent(QDragEnterEvent * event)
{

    if (event->mimeData()->hasFormat(DeckGui::pawnMimeType()))
        event->accept();
    else
        event->ignore();
}

void DeckGui::dragMoveEvent(QDragMoveEvent * event)
{
    if (event->mimeData()->hasFormat(DeckGui::pawnMimeType()))
    {
        event->setDropAction(Qt::MoveAction);
        event->accept();
    }
    else
    {
        event->ignore();
    }
}

void DeckGui::addPawn(const QPixmap & pixmap, const int currentPlayer)
{
    QListWidgetItem * pieceItem = new QListWidgetItem(this);
    pieceItem->setIcon(QIcon(pixmap));
    pieceItem->setData(Qt::UserRole, QVariant(pixmap));
    pieceItem->setData(Qt::UserRole + 1, currentPlayer);

    pieceItem->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable |
                        Qt::ItemIsDragEnabled);
}

void DeckGui::startDrag(Qt::DropActions /*supportedActions*/)
{
    QListWidgetItem * item = currentItem();

    QByteArray itemData;
    QDataStream dataStream(&itemData, QIODevice::WriteOnly);
    QPixmap pixmap = qvariant_cast<QPixmap>(item->data(Qt::UserRole));

    int id = row(item);
    bool inDeck = true;
    int team = qvariant_cast<int>(item->data(Qt::UserRole + 1));
    std::cout << "team startdrag : " << team << std::endl;;

    dataStream << pixmap << id << inDeck << team;

    QMimeData * mimeData = new QMimeData;
    mimeData->setData(DeckGui::pawnMimeType(), itemData);

    QDrag * drag = new QDrag(this);
    drag->setMimeData(mimeData);
    drag->setHotSpot(QPoint(pixmap.width() / 2, pixmap.height() / 2));
    drag->setPixmap(pixmap);

    if (drag->exec(Qt::MoveAction) == Qt::MoveAction)
        delete takeItem(row(item));
}
