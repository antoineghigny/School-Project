#include "deckgui.h"
#include "BoardGui.h"
#include "iostream"
#include <QDrag>
#include <QDragEnterEvent>
#include <QMimeData>
#include <QPainter>
#include "Pawn.h"
#include "QPoint"
#include "Position.h"

#include "QListWidgetItem"

BoardGui::BoardGui(int imageSize, QWidget * parent,
                   ControllerGui * controller)
    : QWidget(parent), m_ImageSize(imageSize), _controller{controller}
{

    setAcceptDrops(true);
    setMinimumSize(m_ImageSize, m_ImageSize);
    setMaximumSize(m_ImageSize, m_ImageSize);

    _hideRed.load(":/images/allPawns/red/12.png");
    _hideBlue.load(":/images/allPawns/blue/12.png");
    _hideBlue = _hideBlue.copy((_hideBlue.width()),(_hideBlue.height()), _hideBlue.width(),_hideBlue.height()).scaled(width() / _controller->getBoardSize(),
                                                                                                                      height() / _controller->getBoardSize(),
                                                                                                                      Qt::IgnoreAspectRatio,
                                                                                                                      Qt::SmoothTransformation);
    _hideRed = _hideRed.copy((_hideRed.width()),(_hideRed.height()), _hideRed.width(),_hideRed.height()).scaled(width() / _controller->getBoardSize(),
                                                                                                                height() / _controller->getBoardSize(),
                                                                                                                Qt::IgnoreAspectRatio,
                                                                                                                Qt::SmoothTransformation);
}

void BoardGui::clear()
{
    pawns.clear();
    highlightedRect = QRect();
    inPlace = 0;
    update();
}

void BoardGui::dragEnterEvent(QDragEnterEvent * event)
{
    if(_controller->getState() == PICK_PAWN){
        _controller->canBeMoved(_firstPos->getX(), _firstPos->getY());
    }

    if (event->mimeData()->hasFormat(DeckGui::pawnMimeType()))
    {
        PawnGui piece;
        piece.rect = targetSquare(event->position().toPoint());

        if(_controller->getState() == SET_UP){
            QByteArray pieceData = event->mimeData()->data(
                        DeckGui::pawnMimeType());
            QDataStream dataStream(&pieceData, QIODevice::ReadOnly);
            dataStream >> piece.pixmap  >> piece.id >>
                    piece.inDeck >> piece.team;
        }

        event->accept();
    }else
        event->ignore();
}

void BoardGui::dragLeaveEvent(QDragLeaveEvent * event)
{
    PawnGui piece;
    QRect updateRect = highlightedRect;
    highlightedRect = QRect();
    update(updateRect);
    event->accept();
    if(_controller->getState() == MOVE_PAWN){
        _controller->isSamePosition(Position(_firstPos->getX(), _firstPos->getY()));
    }
}

void BoardGui::dragMoveEvent(QDragMoveEvent * event)
{
    QRect updateRect = highlightedRect.united(targetSquare(
                                                  event->position().toPoint()));

    PawnGui piece;
    piece.rect = targetSquare(event->position().toPoint());
    auto loc = piece.rect.topLeft() / pawnSize();

    if(_controller->getState() == SET_UP){
        QByteArray pieceData = event->mimeData()->data(
                    DeckGui::pawnMimeType());
        QDataStream dataStream(&pieceData, QIODevice::ReadOnly);
        dataStream >> piece.pixmap  >> piece.id >>
                piece.inDeck >> piece.team;
    }

    if (_controller->getState() == SET_UP &&_controller->canBePut(_controller->getPawnInDeckAt(
                                                                      piece.id), loc.y() + 1,
                                                                  loc.x() + 1))
    {
        highlightedRect = targetSquare(event->position().toPoint());
        event->setDropAction(Qt::MoveAction);
        event->accept();
    } else if(_controller->getState() == MOVE_PAWN && _controller->movePawnGui(Position(loc.y()+1, loc.x() +1))){
        highlightedRect = targetSquare(event->position().toPoint());
        event->setDropAction(Qt::MoveAction);
        event->accept();
    } else
    {
        event->ignore();
    }

    update(updateRect);
}


void BoardGui::dropEvent(QDropEvent * event)
{
    QByteArray pieceData = event->mimeData()->data(
                DeckGui::pawnMimeType());

    QDataStream dataStream(&pieceData, QIODevice::ReadOnly);

    PawnGui piece;
    piece.rect = targetSquare(event->position().toPoint());

    dataStream >> piece.pixmap  >> piece.id >>
            piece.inDeck >> piece.team;

    pawns.append(piece);

    highlightedRect = QRect();
    update(piece.rect);
    auto loc = piece.rect.topLeft() / pawnSize();

    if(_controller->getState() == SET_UP){
        event->setDropAction(Qt::MoveAction);
        event->accept();
        _controller->putPawnAt(_controller->getPawnInDeckAt(piece.id),
                               loc.y() + 1,
                               loc.x() + 1, 1);
    } else if(_controller->getState() == MOVE_PAWN && _controller->movePawnGui(Position(loc.y()+1, loc.x() +1))){
        std::cout << "entre movePawn" << std::endl;
        _controller->movePawn(Position(loc.y()+1, loc.x() +1));
        event->setDropAction(Qt::MoveAction);
        event->accept();
    }
}

int BoardGui::findPiece(const QRect & pieceRect) const
{
    for (int i = 0, size = pawns.size(); i < size; ++i)
    {
        if (pawns.at(i).rect == pieceRect)
            return i;
    }
    return -1;
}

void BoardGui::mousePressEvent(QMouseEvent * event)
{
    int start = (event->position().y() / pawnSize()) + 1;
    int dest = (event->position().x() / pawnSize()) + 1;
    if(_controller->canBeMoved(start, dest) /* ET STATE = PICK PAWN */){
        _firstPos = new Position(start,dest);

        QRect square = targetSquare(event->position().toPoint());
        const int found = findPiece(square);

        if (found == -1)
            return;

        PawnGui piece = pawns.takeAt(found);

        update(square);

        QByteArray itemData;
        QDataStream dataStream(&itemData, QIODevice::WriteOnly);

        dataStream << piece.pixmap  << piece.id <<
                      piece.inDeck << piece.team;

        QMimeData * mimeData = new QMimeData;
        mimeData->setData(DeckGui::pawnMimeType(), itemData);

        QDrag * drag = new QDrag(this);
        drag->setMimeData(mimeData);
        drag->setHotSpot(event->position().toPoint() - square.topLeft());
        drag->setPixmap(piece.pixmap);
        std::cout << "5" << std::endl;

        //  _controller->generateDeck();
        if (drag->exec(Qt::MoveAction) != Qt::MoveAction)
        {
            std::cout << "6" << std::endl;

            pawns.insert(found, piece);
            update(targetSquare(event->position().toPoint()));
        }
    }else{
        event->ignore();
    }
}

void BoardGui::paintEvent(QPaintEvent * event)
{
    QPainter painter(this);
    map.load(":/images/lignes.png");
    painter.fillRect(event->rect(), map.scaled(width(), height()));

    if (highlightedRect.isValid())   // ET SI TRUC ENEMI A LA POSITION POSSIBLE
    {
        QColor color = QColor("#ffcccc");
        color.setAlphaF(0.5);
        painter.setBrush(color);
        painter.setPen(Qt::NoPen);
        painter.drawRect(highlightedRect.adjusted(0, 0, -1, -1));
    }


    // affiche les cases
    for (const PawnGui & pawn : pawns)
    {
        auto loc = pawn.rect.topLeft() / pawnSize();
        painter.drawPixmap(pawn.rect, findPixmap(_controller->getCurrentPlayer(),  Position(loc.y()+1, loc.x()+1), pawn));
    }
}

void BoardGui::updateDuel(Position start, Position pos, Pawn pawn, int duelResult)
{
    std::cout << "updateDUEL" << std::endl;
        Team team = pawn.getTeam();

        int x = pos.getY() - 1;
        int y = pos.getX() - 1;

        QPoint destPos(x * pawnSize(), y * pawnSize());

        PawnGui pawnGui;

        if(duelResult != 2){
            QRect square;
             int found = 0;
            if(duelResult == -1){
                square = targetSquare(destPos);
                found = findPiece(square);
                std::cout << found << std::endl;
                if (!(found == -1)){
                    pawnGui = pawns.takeAt(found); // DELETE
                }
                int found2 = findPiece(square);

                if (!(found == -1)){
                    pawns.takeAt(found2); // DELETE
                }
                pawns.insert(found, pawnGui);

            }else if(duelResult == 1){
                square = targetSquare(destPos);
                found = findPiece(square);
                if (!(found == -1)){
                    pawns.takeAt(found); // DELETE
                }
            }else{
                square = targetSquare(destPos);
                found = findPiece(square);
                std::cout << found << std::endl;
                if (!(found == -1)){
                    pawns.takeAt(found); // DELETE
                }
                int found2 = findPiece(square);

                if (!(found == -1)){
                    pawns.takeAt(found2); // DELETE
                }
            }
        }

}

const QRect BoardGui::targetSquare(const QPoint & position) const
{
    QPoint topLeft = QPoint(position.x() / pawnSize(),
                            position.y() / pawnSize()) * pawnSize();

    return QRect(topLeft, QSize(pawnSize(), pawnSize()));
}

int BoardGui::pawnSize() const
{
    return m_ImageSize / 10;
}

int BoardGui::imageSize() const
{
    return m_ImageSize;
}

void BoardGui::refresh()
{
    //    update();
}

void BoardGui::updateView(Model *m)
{
    std::cout << "updateview board" << std::endl;
    switch (m->getState())
    {
    case PICK_PAWN:
        break;
    case MOVE_PAWN:
        updateDuel(m->getPickedPosition(), m->getDestinationPosition(), m->getPawn(m->getDestinationPosition()), m->getDuelResult());
        break;
    }
}


QPixmap BoardGui::findPixmap(Team currentPlayer, const Position pos, const PawnGui pawn)
{

    if(!_controller->getPawn(pos).isVisible() && currentPlayer != pawn.team){
        if(currentPlayer== 1){
            return _hideBlue;
        }else if(currentPlayer == 0){
            return _hideRed;
        }
    }
    return pawn.pixmap;
}

void BoardGui::placePawnFile(int x, int y, QPixmap pixmap, int team)
{
    auto xPos = x * pawnSize();
    auto yPos = y * pawnSize();

    QPoint pos(x * pawnSize(), y * pawnSize());

    PawnGui piece;

    piece.rect = targetSquare(pos);

    piece.pixmap = pixmap;
    piece.team = team;

    pawns.append(piece);

    highlightedRect = QRect();
    update(piece.rect);
}



