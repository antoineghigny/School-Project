#ifndef DECKGUI_H
#define DECKGUI_H

#include <QListWidget>
#include "QLabel"
#include "QCheckBox"
#include "QPoint"

class DeckGui : public QListWidget
{
    Q_OBJECT

  public:
    explicit DeckGui(int pawnSize, QWidget * parent = nullptr);
    void addPawn(const QPixmap & pixmap, const int currentPlayer);


    static QString pawnMimeType()
    {
        return QStringLiteral("image/pawn");
    }

  protected:
    void dragEnterEvent(QDragEnterEvent * event) override;
    void dragMoveEvent(QDragMoveEvent * event) override;
    void startDrag(Qt::DropActions supportedActions) override;

    int _pawnSize;
};

#endif // DECKGUI_H
