#include "GraveyardsGui.h"

GraveyardsGui::GraveyardsGui(int pawnSize, QWidget * parent)
{
    setDragEnabled(false);
    setViewMode(QListView::IconMode);
    setIconSize(QSize(pawnSize, pawnSize));
    setSpacing(10);
    setAcceptDrops(false);
    setDropIndicatorShown(false);
}

void GraveyardsGui::addPawn(const QPixmap & pixmap)
{
    QListWidgetItem * pieceItem = new QListWidgetItem(this);
    pieceItem->setIcon(QIcon(pixmap));
    pieceItem->setData(Qt::UserRole, QVariant(pixmap));

    pieceItem->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable |
                        Qt::ItemIsDragEnabled);
}
