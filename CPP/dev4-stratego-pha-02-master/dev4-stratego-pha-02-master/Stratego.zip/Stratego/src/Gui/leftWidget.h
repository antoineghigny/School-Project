#ifndef LEFTWIDGET_H
#define LEFTWIDGET_H

#include <QPoint>
#include <QPixmap>
#include <QList>
#include <QWidget>
#include <controllergui.h>
#include <Pawn.h>
#include <QListWidget>
#include <QVBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QCheckBox>

class LeftWidget : public QWidget
{
    Q_OBJECT

  public:

    explicit LeftWidget(QWidget * parent = nullptr,
                  ControllerGui * controller = nullptr);

    void addDeck(QListWidget * gui);

    void addQuestions(QLabel * question, QPushButton * importFile,
                      QPushButton * manualPosition);

    void addDropFile(QLabel * text, QLabel * label);

    void deleteGui();

    void addGraveyards(QListWidget * blue, QListWidget * red);

    void askGameMode(QLabel *question, QCheckBox *gameMode, QPushButton * start);
  private:
    ControllerGui * _controller;

  public slots:
};

#endif // LEFTWIDGET_H
