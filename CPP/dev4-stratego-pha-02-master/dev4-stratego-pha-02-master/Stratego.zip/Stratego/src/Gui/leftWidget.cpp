#include "leftWidget.h"
#include "controllergui.h"
#include "qwidget.h"
#include "QGridLayout"
#include "QListWidget"
#include "QVBoxLayout"
#include "QPushButton"
#include "QLabel"

LeftWidget::LeftWidget(QWidget * parent,
           ControllerGui * controller): QWidget(parent), _controller{controller}
{
    setMinimumSize(500, 500);
    setMaximumSize(2000, 2000);
}

void LeftWidget::addDeck(QListWidget * gui)
{
    deleteGui();
    QGridLayout * centralLayout = new QGridLayout;
    centralLayout->addWidget(gui);
    setLayout(centralLayout);
}


void LeftWidget::addQuestions(QLabel * question, QPushButton * importFile,
                        QPushButton * manualPosition)
{
    deleteGui();
    std::cout << "hey hey" << std::endl;
    QVBoxLayout * centralLayout = new QVBoxLayout;

    centralLayout->setSpacing(20);
    centralLayout->setContentsMargins(10, 10, 10, 10);

    centralLayout->addWidget(question);
    centralLayout->addWidget(manualPosition);
    centralLayout->addWidget(importFile);
    centralLayout->setAlignment(Qt::AlignCenter);
    setLayout(centralLayout);
}

void LeftWidget::addDropFile(QLabel * text, QLabel * label)
{
    deleteGui();

    QVBoxLayout * centralLayout = new QVBoxLayout;
    text->setMaximumHeight(60);
    text->setAlignment(Qt::AlignCenter);
    label->setAlignment(Qt::AlignCenter);

    centralLayout->addWidget(text);
    centralLayout->addWidget(label);

    setLayout(centralLayout);
}

void LeftWidget::deleteGui()
{
    if (layout()) {
            QLayoutItem *item;

            while((item = layout()->takeAt(0)) != 0) {
                if (item->widget()) {
                    layout()->removeWidget(item->widget());
                    delete item->widget();
                }

                    delete item;
           }
            delete layout();
        }
}

void LeftWidget::addGraveyards(QListWidget * blue, QListWidget * red)
{
    deleteGui();
    QVBoxLayout * centralLayout = new QVBoxLayout;
    centralLayout->addWidget(blue);
    centralLayout->addWidget(red);
    setLayout(centralLayout);
}

void LeftWidget::askGameMode(QLabel *question, QCheckBox *gameMode, QPushButton * start)
{
    deleteGui();
    QVBoxLayout * centralLayout = new QVBoxLayout;
    centralLayout->addWidget(question);
    centralLayout->addWidget(gameMode);
    centralLayout->addWidget(start);

    centralLayout->setSpacing(20);
    centralLayout->setContentsMargins(10, 10, 10, 10);
    centralLayout->setAlignment(Qt::AlignCenter);
    setLayout(centralLayout);
}


