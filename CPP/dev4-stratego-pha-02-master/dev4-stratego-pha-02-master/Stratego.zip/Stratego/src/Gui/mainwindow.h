#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPixmap>
#include "QCheckBox"
#include "QLabel"

#include "Observer.h"

class ControllerGui;
class DeckGui;
class BoardGui;
class LeftWidget;
class GraveyardsGui;

QT_BEGIN_NAMESPACE
class QListWidgetItem;
QT_END_NAMESPACE

namespace ui
{
class MainWindow;
}

class MainWindow : public QMainWindow, public Observer
{
    Q_OBJECT

  public:

    explicit MainWindow(QWidget * parent = nullptr,
                        ControllerGui * controller = nullptr);
    void updateView(Model * m);
    void setupWidgets();

  public slots:
    void askPlacement();
    bool valueOfChoice(bool value);
    void setGraveyards();
    void fillGraveyards(int duelResult);
    void setupDeck();
    void setUpFile();
    QLabel * displayCurrentPlayer();
    void setupBoardForFile();
    void inputGameMode();
    void startGame();

  private slots:
    // a remplir

  private:

    void setupMenus();


    QString imagePawn(Role role, Team team);
    QString imagePixmap(Role role, Team team);

    int _sizeBoard;
    QPixmap _pixmap;
    ControllerGui * _controller;
     // liste
    BoardGui  * _boardGui;
    LeftWidget * _leftWidget;

    GraveyardsGui * _blueGraveyards;
    GraveyardsGui * _redGraveyards;

    DeckGui * _deck;

    bool _isImportFile;

    Position _start;
    Position _destination;
    QCheckBox * _checkbox;
};

#endif // MAINWINDOW_H
