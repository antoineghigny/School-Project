#include "ControllerGui.h"
#include <Game.h>
#include <mainwindow.h>

#include <Position.h>
#include <Team.h>


ControllerGui::ControllerGui():
    _game{}
{

}

void ControllerGui::addObserver(Observer * o)
{
    _game.addObserver(o);
}

void ControllerGui::loadFile(std::string path)
{
    _game.loadFile(path);
}

Team ControllerGui::getCurrentPlayer()
{
    return this->_game.getCurrentPlayer();
}

void ControllerGui::isSamePosition(Position pos)
{
    _game.isSamePosition(pos);
}

bool ControllerGui::movePawnGui(Position pos)
{
    try{
        return _game.isCorrectMove(pos);
    }catch(std::invalid_argument & exception)
    {
        return false;
    }

}

void ControllerGui::movePawn(Position pos)
{
    std::cout << pos.getX() << " : " << pos.getY() << std::endl;
    try{
        _game.movePawnGui(pos);

    }catch(std::out_of_range & exception){
        std::cout << "catch exception " << std::endl;
    }
}

Position ControllerGui::getDestinationPosition()
{
    return _game.getDestinationPosition();
}



Pawn ControllerGui::getPawnInDeck()
{
    std::cout << "getPawnInDeck" << std::endl;

    return _game.getPawnInDeck();
}

Pawn ControllerGui::getPawnInDeckAt(int index)
{
    std::cout << "getPawnInDeckAt" << std::endl;
    return _game.getPawnInDeckAt(index);
}

void ControllerGui::putPawn(Pawn pawn, int x, int y)
{
    auto position = Position(x, y);
    _game.putPawn(pawn, position);
}

void ControllerGui::putPawnAt(Pawn pawn, int x, int y, int index)
{
    std::cout << "putpawnat" << std::endl;
    auto position = Position(x, y);
    _game.putPawnAt(pawn, position, index);
}

Team ControllerGui::getWinner()
{
    return _game.getWinner();
}

bool ControllerGui::canBePut(Pawn pawn, int x, int y)
{
    return _game.canBePut(pawn, Position(x, y));
}

bool ControllerGui::canBeMoved(int x, int y)
{
    return _game.canBePick(Position(x, y));
}

Role ControllerGui::getDeadPawnRole(int playerNumber, int index)
{
    return _game.getRoleOfDeadPawn(playerNumber, index);
}

void ControllerGui::generateDeck()
{
    std::cout << "generateDeck" << std::endl;

    this->_game.generateDeck();
}

int ControllerGui::getDeckSize()
{
    std::cout << "getDeckSize" << std::endl;

    return _game.getDeckSize();
}

int ControllerGui::getBoardSize()
{
    return _game.getBoardSideSize();
}

int ControllerGui::numberOfDeadSoldier(int playerNumber)
{
    return _game.numberOfDeadSoldier(playerNumber);
}

std::string ControllerGui::deadPawnToString(int pos, int playerNumber)
{
    return _game.deadPawnToString(pos, playerNumber);
}

Pawn ControllerGui::getPawn(Position position)
{
    return _game.getPawn(position);
}

std::pair<Role, Team> ControllerGui::getLastDeadPawn(int playerNumber)
{
    return _game.getLastDeadPawn(playerNumber);
}

void ControllerGui::switchPos()
{
}

State ControllerGui::getState()
{
    return _game.getState();
}

void ControllerGui::checkInputGameMode(bool easyMode)
{
    _game.start(easyMode);
}

bool ControllerGui::isSetUpFinish(){
    return _game.isSetUpFinish();
}

void ControllerGui::setToSetUpFinish(){
    _game.setToSetUpFinish();
}


