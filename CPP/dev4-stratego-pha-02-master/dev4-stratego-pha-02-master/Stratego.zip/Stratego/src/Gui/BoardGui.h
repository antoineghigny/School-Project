#ifndef BOARDGUI_H
#define BOARDGUI_H

#include <QPoint>
#include <QPixmap>
#include <QList>
#include <QWidget>
#include "controllergui.h"
#include "Pawn.h"
#include "DeckGui.h"
#include "Observer.h"

QT_BEGIN_NAMESPACE
class QDragEnterEvent;
class QDropEvent;
class QMouseEvent;
QT_END_NAMESPACE

class BoardGui : public QWidget, public Observer
{
    Q_OBJECT

  public:

    explicit BoardGui(int imageSize, QWidget * parent = nullptr,
                      ControllerGui * controller = nullptr);
    void clear();

    int pawnSize() const;
    int imageSize() const;
    DeckGui * getDeck();
    void refresh();

    void updateView(Model * m);
    void placePawnFile(int x, int y, QPixmap pixmap, int team);
  signals:

  protected:
    void dragEnterEvent(QDragEnterEvent * event) override;
    void dragLeaveEvent(QDragLeaveEvent * event) override;
    void dragMoveEvent(QDragMoveEvent * event) override;
    void dropEvent(QDropEvent * event) override;
    void mousePressEvent(QMouseEvent * event) override;
    void paintEvent(QPaintEvent * event) override;
    void updateDuel(Position start, Position pos, Pawn pawn, int duelResult);

  private:
    ControllerGui * _controller;

    struct PawnGui
    {
        QPixmap pixmap;
        QRect rect;
        int id;
        bool inDeck;
        int team;
    };

    QPixmap findPixmap(Team currentPlayer, const Position pos, const PawnGui pawn);

    int findPiece(const QRect & pieceRect) const;
    const QRect targetSquare(const QPoint & position) const;

    QList<PawnGui> pawns;
    QRect highlightedRect;
    int inPlace;
    int m_ImageSize;
    QPixmap map;

    QPixmap _hideRed;
    QPixmap _hideBlue;

    Position * _firstPos;
    Position * _lastPos;

};

#endif // BOARDGUI_H
