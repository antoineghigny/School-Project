#ifndef GAMERESULT_H
#define GAMERESULT_H

enum GameResult {VICTORY, DEFEAT, EGALITY, CONTINUE};

#endif // GAMERESULT_H
