#ifndef TEAM_H
#define TEAM_H

/**
 * @brief The Team enum represents the team in which a player of the game is.
 */
enum Team{BLUE, RED, NONE};

#endif // TEAM_H
